# JNT – Jyothi Naik Thanda Website

## Files
- `index.html` — complete responsive website. CSS is included in the file.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` to the repository's main/root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish the site. The website link will appear in the Pages section.

Note: `127.0.0.1:8000` is a local address and cannot be accessed by other people. GitHub Pages gives your site a public `github.io` address.

You can edit the text in `index.html` and add your own photos later.
